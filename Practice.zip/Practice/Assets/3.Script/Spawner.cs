using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    [SerializeField]
    private GameObject DDONG_Prefab;

    public Queue<GameObject> Pool_Q;

    [SerializeField]
    private float SpawnTime;

    private float x;
    private float y;
    private float z;

    private Vector3 poolPos;

    public int Prefabs_Count = 10;


    private void Awake()
    {

        Pool_Q = new Queue<GameObject>(Prefabs_Count);
        SpawnTime = 1f;
       
        //��ġ�� �˶����� ���� ���ؼ� x,y,z �ٲٱ�!_!

        Init();

        SpawnTime = 1f;
        SpawnDDong_Coroutine();
    }

    private void Init()
    {
        for (int i = 0; i < Prefabs_Count; i++)
        {
            //GameObject newDDONG = Instantiate(DDONG_Prefab, poolPos, Quaternion.identity);
            Pool_Q.Enqueue(ObjectPooling());
        }
    }


    private GameObject ObjectPooling()
    {
        x = Random.Range(-7, 7);
        y = 10f;
        z = Random.Range(-7, 7);
        poolPos = new Vector3(x, y, z);
        GameObject newDDONG = Instantiate(DDONG_Prefab, poolPos, Quaternion.identity);
        newDDONG.gameObject.SetActive(true);
        newDDONG.transform.SetParent(transform);
        return newDDONG;
    }

    private IEnumerator SpawnDDong_Coroutine()
    {
        WaitForSeconds seconds = new WaitForSeconds(SpawnTime);
        while (true)
        {
            Vector3 Position = poolPos;

            TakeOut_Pool(Position);

            yield return seconds;

        }
    }

    public void TakeOut_Pool(Vector3 position)
    {
        if (Pool_Q.Count <= 0)
        {
            return;
        }

        GameObject DDONG = Pool_Q.Dequeue();
        if (DDONG.activeSelf == false)
        {
            DDONG.SetActive(true);
        }
    }

    public void TakeIn_Pool(GameObject ddong)
    {
        ddong.transform.position = poolPos;

        if (ddong.activeSelf)
        {
            ddong.SetActive(false);
        }
        Pool_Q.Enqueue(ddong);
    }
}
